class DashboardsController < ApplicationController

  def index; end

end