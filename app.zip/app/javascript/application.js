// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import "@hotwired/turbo-rails"
import "app/assets/javascript/controllers"


//= require jquery
//= require jquery_ujs
//= require rails-ujs
//= require ../../../../../../../.rvm/gems/ruby-3.2.0/gems/activestorage-7.0.4.3/app/assets/javascripts/activestorage
//= require turbolinks
//= require bootstrap
//= require_tree .
